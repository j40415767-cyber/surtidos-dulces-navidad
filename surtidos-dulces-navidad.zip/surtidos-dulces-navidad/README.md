# NOVA — tienda online (plantilla inicial)

Tienda de demostración responsive construida con HTML, CSS y JavaScript sin dependencias de instalación.

## Incluye
- Diseño responsive para móvil y escritorio.
- Portada, catálogo, filtros, búsqueda y ordenación por precio.
- Carrito funcional en el navegador con cantidades y subtotal.
- Persistencia del carrito con `localStorage`.
- Animaciones con respeto a `prefers-reduced-motion`.
- Secciones de marca, valores, preguntas frecuentes y newsletter de demostración.

## Antes de publicar
Esta versión es un **prototipo de frontend**, no una tienda lista para cobrar pedidos. El checkout y el formulario de newsletter son demostraciones.

1. Cambia el nombre `NOVA` por el de tu marca en `index.html` y revisa el título/descripción.
2. Edita el array `products` de `app.js` con tus productos reales, precios e imágenes con licencia o que tengas derecho a usar.
3. Actualiza envíos, devoluciones, privacidad, aviso legal, contacto y cualquier información comercial.
4. Conecta un proveedor de pagos (por ejemplo Stripe o PayPal) mediante un backend o integración segura. **No pongas claves secretas en `app.js` ni guardes datos de tarjetas en tu web.**
5. Configura gestión real de pedidos, impuestos, stock, confirmaciones y correos.
6. Prueba en móvil y escritorio antes de aceptar compras reales.

## Probar en tu ordenador
Abre `index.html` en un navegador. Para un entorno local más fiable, puedes usar la extensión Live Server de VS Code.

## Publicar gratis con GitHub Pages (prototipo estático)
1. Crea un repositorio nuevo en GitHub, por ejemplo `mi-tienda`.
2. Sube `index.html`, `styles.css` y `app.js` (y este README).
3. En el repositorio, abre **Settings → Pages**.
4. En **Build and deployment**, selecciona **Deploy from a branch**, elige `main` y `/ (root)`, y guarda.
5. GitHub mostrará la URL pública cuando termine el despliegue.

GitHub Pages solo aloja archivos estáticos. Para pagos reales, gestión de pedidos o cuentas de clientes, usa un backend y un alojamiento adecuados. No anuncies la tienda como operativa hasta que el flujo de pago y las obligaciones legales estén verificados.
