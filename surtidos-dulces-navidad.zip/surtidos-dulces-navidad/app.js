// Catálogo de demostración. Sustituye estos productos por los reales.
const products = [
  {id:1,name:"Surtido clásico navideño",category:"Surtidos",price:18.90,tag:"PARA COMPARTIR",image:"https://images.unsplash.com/photo-1549007994-cb92caebd54b?auto=format&fit=crop&w=900&q=85",alt:"Selección de dulces y chocolates"},
  {id:2,name:"Caja de chocolates",category:"Chocolates",price:14.50,tag:"IDEA DE REGALO",image:"https://images.unsplash.com/photo-1481391319762-47dff72954d9?auto=format&fit=crop&w=900&q=85",alt:"Chocolates para regalar"},
  {id:3,name:"Golosinas para fiestas",category:"Golosinas",price:9.90,tag:"PARA LOS PEQUES",image:"https://images.unsplash.com/photo-1582058091505-f87a2e55a40f?auto=format&fit=crop&w=900&q=85",alt:"Dulces de colores"},
  {id:4,name:"Lote dulce para regalar",category:"Lotes regalo",price:24.90,tag:"EDICIÓN ESPECIAL",image:"https://images.unsplash.com/photo-1512909006721-3d6018887383?auto=format&fit=crop&w=900&q=85",alt:"Caja de regalo preparada para sorprender"}
]
const euro = value => new Intl.NumberFormat("es-ES",{style:"currency",currency:"EUR"}).format(value);
let cart = JSON.parse(localStorage.getItem("nova-cart") || "[]");
let activeFilter = "Todos";
let searchTerm = "";

const grid = document.querySelector("#product-grid");
const cartDrawer = document.querySelector("#cart-drawer");
const overlay = document.querySelector("#overlay");
const cartItems = document.querySelector("#cart-items");
const toast = document.querySelector("#toast");

function visibleProducts(){
  let list = products.filter(p => (activeFilter === "Todos" || p.category === activeFilter) &&
    (p.name.toLowerCase().includes(searchTerm) || p.category.toLowerCase().includes(searchTerm)));
  const sort = document.querySelector("#sort-select").value;
  if(sort === "low") list.sort((a,b)=>a.price-b.price);
  if(sort === "high") list.sort((a,b)=>b.price-a.price);
  return list;
}
function renderProducts(){
  const list = visibleProducts();
  if(!list.length){grid.innerHTML='<p class="empty-results">No encontramos productos con esa búsqueda.</p>';return;}
  grid.innerHTML = list.map((p,i)=>`
    <article class="product-card" style="animation-delay:${i*65}ms">
      <div class="product-image">
        <img src="${p.image}" alt="${p.alt}" loading="lazy">
        <span class="product-tag">${p.tag}</span>
        <button class="quick-add" data-add="${p.id}">AÑADIR A LA BOLSA ＋</button>
      </div>
      <div class="product-meta"><div class="product-name-row"><h3 class="product-name">${p.name}</h3><span class="product-price">${euro(p.price)}</span></div><p class="product-category">${p.category}</p></div>
    </article>`).join("");
}
function saveCart(){localStorage.setItem("nova-cart",JSON.stringify(cart));renderCart();}
function addToCart(id){
  const found=cart.find(item=>item.id===id);
  if(found) found.qty++; else cart.push({id,qty:1});
  saveCart();showToast("Añadido a tu bolsa");openCart();
}
function changeQty(id,delta){
  const item=cart.find(x=>x.id===id);if(!item)return;
  item.qty+=delta;if(item.qty<1)cart=cart.filter(x=>x.id!==id);
  saveCart();
}
function renderCart(){
  const count=cart.reduce((sum,item)=>sum+item.qty,0);
  document.querySelector("#cart-count").textContent=count;
  document.querySelector("#drawer-count").textContent=`(${count})`;
  const subtotal=cart.reduce((sum,item)=>{const p=products.find(p=>p.id===item.id);return sum+(p?p.price*item.qty:0)},0);
  document.querySelector("#cart-subtotal").textContent=euro(subtotal);
  document.querySelector("#cart-empty").hidden=count>0;
  document.querySelector("#drawer-footer").hidden=count===0;
  cartItems.innerHTML=cart.map(item=>{
    const p=products.find(p=>p.id===item.id);if(!p)return "";
    return `<div class="cart-line"><img src="${p.image}" alt="${p.alt}"><div><h3>${p.name}</h3><p>${euro(p.price)}</p><div class="qty-controls"><button data-qty="${p.id}" data-delta="-1" aria-label="Restar uno">−</button><span>${item.qty}</span><button data-qty="${p.id}" data-delta="1" aria-label="Añadir uno">＋</button></div></div><button class="remove-item" data-remove="${p.id}" aria-label="Eliminar ${p.name}">×</button></div>`;
  }).join("");
}
function openCart(){cartDrawer.hidden=false;overlay.hidden=false;document.body.style.overflow="hidden";document.querySelector("#cart-close").focus();}
function closeCart(){cartDrawer.hidden=true;overlay.hidden=true;document.body.style.overflow="";}
let toastTimer;
function showToast(message){toast.textContent=message;toast.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove("show"),2300);}

grid.addEventListener("click",e=>{const button=e.target.closest("[data-add]");if(button)addToCart(Number(button.dataset.add));});
document.querySelectorAll(".filter").forEach(button=>button.addEventListener("click",()=>{
  document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b===button));
  activeFilter=button.dataset.filter;renderProducts();
}));
document.querySelector("#sort-select").addEventListener("change",renderProducts);
document.querySelector("#cart-open").addEventListener("click",openCart);
document.querySelector("#cart-close").addEventListener("click",closeCart);
document.querySelector("#continue-shopping").addEventListener("click",closeCart);
overlay.addEventListener("click",closeCart);
cartItems.addEventListener("click",e=>{
  const qty=e.target.closest("[data-qty]"),remove=e.target.closest("[data-remove]");
  if(qty)changeQty(Number(qty.dataset.qty),Number(qty.dataset.delta));
  if(remove){cart=cart.filter(item=>item.id!==Number(remove.dataset.remove));saveCart();}
});
document.querySelector("#checkout-button").addEventListener("click",()=>{
  showToast("El pago aún no está conectado. Consulta el README para configurarlo.");
});
document.querySelector("#search-toggle").addEventListener("click",()=>{
  const strip=document.querySelector("#search-strip");strip.hidden=!strip.hidden;
  if(!strip.hidden)document.querySelector("#search-input").focus();
});
document.querySelector("#search-close").addEventListener("click",()=>{
  document.querySelector("#search-strip").hidden=true;
  document.querySelector("#search-input").value="";searchTerm="";renderProducts();
});
document.querySelector("#search-input").addEventListener("input",e=>{searchTerm=e.target.value.trim().toLowerCase();renderProducts();});
document.querySelector("#menu-toggle").addEventListener("click",()=>{
  const nav=document.querySelector("#mobile-nav");nav.hidden=!nav.hidden;
});
document.querySelector("#mobile-nav").querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>document.querySelector("#mobile-nav").hidden=true));
document.querySelector("#newsletter-form").addEventListener("submit",e=>{
  e.preventDefault();document.querySelector("#newsletter-message").textContent="¡Gracias! El formulario es una demo y aún no guarda suscripciones.";
  e.target.reset();
});
document.querySelector("#year").textContent=new Date().getFullYear();
document.addEventListener("keydown",e=>{if(e.key==="Escape"&&!cartDrawer.hidden)closeCart();});

if("IntersectionObserver" in window){
  const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{
    if(entry.isIntersecting){entry.target.classList.add("visible");observer.unobserve(entry.target);}
  }),{threshold:.12});
  document.querySelectorAll(".reveal").forEach(el=>observer.observe(el));
}else{document.querySelectorAll(".reveal").forEach(el=>el.classList.add("visible"));}

renderProducts();renderCart();
